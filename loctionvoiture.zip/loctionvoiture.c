#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include<conio.h>
#include<dos.h>
#include<windows.h>
#include<time.h>
/*NOM:BOURZGUI
  PRENOM:FATIMA ZAHRA
  GROUPE:G2a
  CIN:JM79734*/
typedef struct Date
{ 
  int jj;
  int mm;
  int aa;
} date;
typedef struct Voiture
{ 
  int idVoiture;
  char marque[15];
  char nomVoiture[15];
  char couleur[7];
  int nbplaces;
  int prixJour;
  char EnLocation[4];
} voiture;
typedef struct contratLocation
{ 
  float numContrat;
  int idVoiture;
  int idClient;
   date debut;
   date fin;
   int cout;
} contrat;
typedef struct Client
{ 
   int idClient;
   char nom[20];
   char prenom[20];
   int cin;
   char adresse[15];
   int telephone;
} client;
void EnTete()
{
	system("cls");
	system("color 70");
	char tmpbuf[128],datebuf[128];
    _strtime( tmpbuf );
    _strdate( datebuf );
	printf("\xc9");
	printf("\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcb\xcd");
	printf("\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcb\xcd");
	printf("\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcb\xcd");
	printf("\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcb\xcd");
	printf("\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd");
	printf("\xbb");
	printf("\n\xba %s \xba		      \xba Location voiture \xba 		   \xba %s \xba\n",tmpbuf,datebuf);	
	printf("\xc8");
	printf("\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xca\xcd");
	printf("\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xca\xcd");
	printf("\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xca\xcd");
	printf("\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xca\xcd");
	printf("\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd");
	printf("\xbc");
	printf("\n\n");
}
void affichage_voiture()
{ 
  voiture ch[1000];
  FILE* Fichier=NULL;
  Fichier=fopen("Voitures.txt","r");
  if(Fichier!=NULL)
    {
        while(fgets(&ch,1000,Fichier)!=NULL)
        {
            printf("%s",ch);
        }

       fclose(Fichier);
    }
   else 
        printf("erreur,fichier introuvable!");
  }

void Ajoute_voiture()
{  
    voiture ch;
    printf("saisir l'id du voiture :\n");
    scanf("%d",&ch.idVoiture);
    printf("saisir la marque du voiture :\n");
    scanf("%s",ch.marque);
    printf("saisir le nom du voiture :\n");
    scanf("%s",ch.nomVoiture);
    printf("saisir la couleur du voiture :\n");
    scanf("%s",ch.couleur);
    printf("saisir le nombre de places :\n");
    scanf("%d",&ch.nbplaces);
    printf("saisir le prix pour jour :\n");
    scanf("%d",&ch.prixJour);
    printf("saisir si en location (oui|non):\n ");
    scanf("%s",ch.EnLocation);
    FILE* Fichier=fopen("Voitures.txt","a");
     if(Fichier!=NULL)
     {  
	     fprintf(Fichier,"id de voiture:%d|marque de voiture:%s|nom de voiture:%s|couleur de voiture:%s|nombre de places:%d|prix par jour:%d|location:%s\n",ch.idVoiture,ch.marque,ch.nomVoiture,ch.couleur,ch.nbplaces,ch.prixJour,ch.EnLocation);
         fclose(Fichier);
     }
     else
        printf("erreur!\n");
}
void Modifier_voiture() 
{ 
   int i,id,n;
   voiture vt[1000];
   FILE* fichier=NULL;
   FILE* fichierv=NULL;
   fichier=fopen("Voitures.txt","r");
   fichierv=fopen("filev.txt","w");
 if(fichier==NULL)
 {
    printf("erreur!\n");
 }
  else
  {
    printf("saisir l'id du voiture que vous voulez modifier :\n");
    scanf("%d",&id);
       while(i<1000 && !feof(fichier))
           {
		    fscanf(fichier,"\n id du voiture: %d|marque du voiture: %s|nom du voiture: %s|couleur du voiture: %s|nombre de places: %d|prix par jour: %d|en location: %s",&vt[i].idVoiture,vt[i].marque,vt[i].nomVoiture,vt[i].couleur,&vt[i].nbplaces,&vt[i].prixJour,vt[i].EnLocation );
               if(vt[i].idVoiture==id)
                  {   
                    do{
				      printf("tapez ce que vous voulez modifier");
				      printf("1-modifier id de voiture\n");
					  printf("2-modifier la marque de voiture\n");
					  printf("3-modifier le nom de voiture\n");
					  printf("4-modifier la couleur\n");
					  printf("5-modifier nombre de places\n");
					  printf("6-modifier le prix\n");
					  printf("7-modifier la location\n");
                      scanf("%d",&n);
                        switch(n)
                            {
							 case 1:
							         printf("saisir l'id du voiture que vous voulez mettre :\n");
                                      scanf("%d",&vt[i].idVoiture);
                                      break;
                              case 2:
							          printf("saisir la marque que vous voulez mettre :\n");
                                      scanf("%s",vt[i].marque);
                                      break;
                               case 3:
							           printf("saisir le nom que vous voulez mettre :\n");
                                       scanf("%s",vt[i].nomVoiture);
                                       break;
                               case 4: 
							         printf("saisir la couleur que vous voulez mettre :\n");
                                     scanf("%s",vt[i].couleur);
                                     break;
                                case 5: 
								         printf("saisir le nombre de place que vous voulez mettre :\n");
                                         scanf("%d",&vt[i].nbplaces);
                                         break;
                                 case 6: 
								         printf("saisir le prix que vous voulez mettre :\n");
                                         scanf("%d",&vt[i].prixJour);
                                         break;
                                  case 7: 
								         printf("saisir oui si la voiture est lou� non sinon");
                                         scanf("%s",vt[i].EnLocation);
                                         break;
                                   default:
								           printf("valeur incorrect entrer un entier entre 1 et7 \n");
                                           break;
                                }
            }while(n<0||n>7);
        }
       fprintf(fichierv,"\n id de voiture:%d|marque de voiture:%s|nom de voiture:%s|couleur de voiture:%s|nombre de places:%d|prix par jour:%d|location:%s \n",vt[i].idVoiture,vt[i].marque,vt[i].nomVoiture,vt[i].couleur,vt[i].nbplaces,vt[i].prixJour,vt[i].EnLocation ) ;
         i++;
        }
     fclose(fichier);
     fclose(fichierv);
     remove("Voitures.txt");
     rename("filev.txt","Voitures.txt");
  }
}
void Supprimer_voiture()
{
   int id_v;
   voiture vt[1000];
   int i;
   FILE* fichier=NULL;
   FILE* fichierv=NULL;
   fichier=fopen("Voitures.txt","r");
   fichierv=fopen("filev.txt","w");
   if(fichier==NULL)
   { 
   printf("erreue!\n");
   }
   else
   { 
      printf("tapez l'id du voiture que vous voulez suprimer :\n");
      scanf("%d",&id_v);
       while (i<1000 && !feof(fichier))
          {  
		   fscanf(fichier,"\n id de voiture:%d|marque de voiture:%s|nom de voiture:%s|couleur de voiture:%s|nombre de places:%d|prix par jour:%d|location:%s",&vt[i].idVoiture,vt[i].marque,vt[i].nomVoiture,vt[i].couleur,&vt[i].nbplaces,&vt[i].prixJour,vt[i].EnLocation );
                if(vt[i].idVoiture!=id_v)
                  {
                      fprintf(fichierv,"\n id de voiture:%d|marque de voiture:%s|nom de voiture:%s|couleur de voiture:%s|nombre de places:%d|prix par jour:%d|location:%s",vt[i].idVoiture,vt[i].marque,vt[i].nomVoiture,vt[i].couleur,vt[i].nbplaces,vt[i].prixJour,vt[i].EnLocation );
                  }
            i++;
       }
       fclose(fichier);
       fclose(fichierv);
       remove("Voitures.txt");
       rename("filev.txt","Voitures.txt");
   }
}
void Afficher_client()
{ 
    voiture ch[1000];
    FILE* Fclient=NULL;
    Fclient=fopen("Clients.txt","r");
    if(Fclient!=NULL)
     {
      while(fgets(ch,1000,Fclient)!=NULL)
      {
          printf("%s",ch);
      }
     fclose(Fclient);
      }
  else
    printf("erreur! fichier introuvable\n");
}
void Ajoute_client() 
{
    client ch;
    printf("saisir l'id de client :\n");
    scanf("%d",&ch.idClient);
    printf("saisir le nom de client :\n");
    scanf("%s",ch.nom);
    printf("saisir le prenom de client :\n");
    scanf("%s",ch.prenom);
    printf("saisir le cin de client :\n");
    scanf("%d",&ch.cin);
    printf("saisir l'adresse de client :\n");
    scanf("%s",ch.adresse);
    printf("saisir le num�ro de telephone de client :\n");
    scanf("%d",&ch.telephone);
    FILE* Fclient=NULL;
     Fclient=fopen("Clients.txt","a");
     if(Fclient!=NULL)
     {
	   fprintf(Fclient,"id de client:%d|nom de client:%s|prenom de client:%s|cin de client:%d|adresse de client:%s|telephone de client:%d \n",ch.idClient,ch.nom,ch.prenom,ch.cin,ch.adresse,ch.telephone);
       fclose(Fclient);
     }
     else
        printf("erreur!\n");
}
void Modifier_client()
{ 
  int i=0,id,n;
  client cl[1000];
  FILE* fichierc=NULL;
  FILE* fiche=NULL;
  fichierc=fopen("Clients.txt","r");
  fiche=fopen("filecl.txt","w");
  if(fichierc==NULL)
  {
      printf("erreur! fichhier introuvable\n");
  }
  else
    { 
	   printf("saisir l'id du client que vous voulez modifier :\n");
       scanf("%d",&id);
        while(i<1000 && !feof(fichierc))
             { 
			   fscanf(fichierc,"id de client:%d|nom de client:%s|prenom de client:%s|cin de client:%d|adresse de client:%s|telephone:%d \n",&cl[i].idClient,cl[i].nom,cl[i].prenom,&cl[i].cin,cl[i].adresse,&cl[i].telephone);
                 if(cl[i].idClient==id)
                    {  
					  do{
					   printf("tapez ce que vous voulez modifier \n");
					   printf("1-le nom de client\n");
					   printf("2-le prenom de client\n");
					   printf("3-cin de client\n");
					   printf("4-adresse de client\n");
					   printf("5-telephone de client\n");
                       scanf("%d",&n);
                        switch(n)
                          { 
						    case 1: 
							        printf("saisir le nouveau nom :\n");
                                    scanf("%s",cl[i].nom);
                                    break;
                            case 2: 
							        printf("saisir le nouveau prenom :\n");
                                    scanf("%s",cl[i].prenom);
                                    break;
                             case 3:
							         printf("saisir le nouveau cin :\n");
                                     scanf("%d",&cl[i].cin);
                                     break;
                             case 4:
							         printf("saisir la nouvelle adresse :\n");
                                     gets(cl[i].adresse);
                                     break;
                            case 5:
							        printf("saisir le nouveau num�ro de telephone :\n");
                                    scanf("%d",&cl[i].telephone);
                                    break;
                            default:
							        printf("erreur!!!\n tapez une valeur entre 1 et 5 :\n");
                                    break;
                         }
                 }while(n<0||n>5);
			
       fprintf(fiche,"\n id de client:%d|nom de client:%s|prenom de client:%s|cin de client:%d|adresse de client:%s|telephone de client:%d",cl[i].idClient,cl[i].nom,cl[i].prenom,cl[i].cin,cl[i].adresse,cl[i].telephone);
           i++;
          }
       fclose(fichierc);
       fclose(fiche);
       remove("Clients.txt");
       rename("filecl.txt","Clients.txt");
     }
}
}
void supprimer_client()
{ 
  int id_c,i;
  client cl[1000];
  FILE* fichierc=NULL;
  FILE* fichierc2=NULL;
  fichierc=fopen("Clients.txt","r");
  fichierc2=fopen("fileclt.txt","w");
  printf("saisir l'id du client que vous voulez supprimer :\n");
  scanf("%d",&id_c);
  if(fichierc==NULL)
  {
    printf("erreur! fichier innexistant \n");
  }
  else
  { 
    while(i<1000 && !feof(fichierc))
       { 
	        fscanf(fichierc,"\n id de client:%d|nom de client:%s|prenom de client:%s|cin de client:%d|adresse de client:%s|telephone de client:%d",&cl[i].idClient,cl[i].nom,cl[i].prenom,&cl[i].cin,cl[i].adresse,&cl[i].telephone);
                if(cl[i].idClient!=id_c)
                 {
				    fprintf(fichierc2,"\n id de client:%d|nom de client:%s|prenom de client:%s|cin de client:%d|adresse de client:%s|telephone de client:%d",cl[i].idClient,cl[i].nom,cl[i].prenom,cl[i].cin,cl[i].adresse,cl[i].telephone);
                 }
                 i++;
      }
     fclose(fichierc);
     fclose(fichierc2);
     remove("Clients.txt");
     rename("fileclt.txt","Clients.txt");
}
}
void Visualiser_contrat()
{ 
  float numctrt;
  int i;
  contrat ch[1000];
  printf("saisir le numero de contrat que vous voulez visualisez :\n");
    scanf("%f",&numctrt);
    FILE* Fcontrat=NULL;
    Fcontrat=fopen("ContratsLocations.txt","r");
     if(Fcontrat!=NULL)
     {
         while(i<1000 || !feof(Fcontrat))
         { 
		 fscanf(Fcontrat,"\n N� de contrat:%f|id de voiture:%d|id de client:%d|date de debut:%d/%d/%d|date de fin:%d/%d/%d|total:%d",&ch[i].numContrat,&ch[i].idVoiture,&ch[i].idClient,&ch[i].debut.jj,&ch[i].debut.mm,&ch[i].debut.aa,&ch[i].fin.jj,&ch[i].fin.mm,&ch[i].fin.aa,&ch[i].cout);
             if(ch[i].numContrat==numctrt)
             {
            printf("\n N�de contrat:%f|id de voiture:%d|id de client:%d|date de debut:%d/%d/%d|date de fin:%d/%d/%d|total:%d",ch[i].numContrat,ch[i].idVoiture,ch[i].idClient,ch[i].debut.jj,ch[i].debut.mm,ch[i].debut.aa,ch[i].fin.jj,ch[i].fin.mm,ch[i].fin.aa,ch[i].cout);
             }
              i++;
         }
       fclose(Fcontrat);
     }
     else
        printf("erreur! fichier innexistant\n");
}

void Louer_voiture()
{ 
 int i=0,id_c,durloc,id_v,rep,findc=0;
 client cl[1000];
 voiture vt[1000];
 contrat ct;
 FILE* fichier=NULL;
 FILE* fiche=NULL;
 printf("saisir l'id du client :\n");
 scanf("%d",&id_c);
 fichier=fopen("Clients.txt","r");
 if(fichier!=NULL)
 {  while(i<1000 && !feof(fichier))
    {   fscanf(fichier,"\n id de client:%d|nom de client:%s|prenom de client:%s|cin de client:%d|adresse de client:%s|telephone de client:%d",&cl[i].idClient,cl[i].nom,cl[i].prenom,&cl[i].cin,cl[i].adresse,&cl[i].telephone);
          if(cl[i].idClient==id_c)
           findc=1;
      i++;
    }
    fclose(fichier);
    if(findc==0)
    {   do{
	    printf("vous voullez ajouter un client ?\n");
	    printf(" 1-oui \n");
		printf(" 2-non \n");
        scanf("%d",&rep);
          if(rep==1)
            Ajoute_client();
          else 
		     Louer_voiture();    
    }while(rep<0||rep>2);
 }
 else { 
       printf("erreur! fichier introuvable \n"); }
      fiche=fopen("Voitures.txt","r");
	 if(fiche!=NULL)
       {  
	     while(i<1000 && !feof(fiche))
          { 
		   fscanf(fiche,"\n id de voiture:%d|marque de voiture:%s|nom de voiture:%s|couleur de voiture:%s|nombre de places:%d|prix par jour:%d|loction:%s",&vt[i].idVoiture,vt[i].marque,vt[i].nomVoiture,vt[i].couleur,&vt[i].nbplaces,&vt[i].prixJour,vt[i].EnLocation);
     if(strcmp(vt[i].EnLocation,"non")==0)
       {
           printf("\n id de voiture:%d|marque de voiture:%s|nom de voiture:%s|couleur de voiture:%s|nombre de places:%d|prix par jour:%d|location:%s",vt[i].idVoiture,vt[i].marque,vt[i].nomVoiture,vt[i].couleur,vt[i].nbplaces,vt[i].prixJour,vt[i].EnLocation);
       }
        i++;
     }
    fclose(fiche);
     printf("saisir l'id du voiture que vous choisissez :\n");
     scanf("%d",&ct.idVoiture);
     printf("saisir  le num�ro de contrat :\n");
     scanf("%d",& ct.numContrat);
     printf("saisir la dur�e de location :\n");
     scanf("%d",&durloc);
     ct.idClient=id_c;
     printf("saisir la date du jour de location sous forme jour/moi/ann�e :\n ");
     scanf("%d %d %d",&ct.debut.jj,&ct.debut.mm,&ct.debut.aa);
     ct.fin.jj=ct.debut.jj+durloc;
     if(ct.fin.jj>30)
     {ct.fin.mm=ct.debut.mm+1;
      ct.fin.jj=ct.fin.jj-30;
     }
     else
        { ct.fin.mm=ct.debut.mm;
        }
     ct.fin.aa=ct.debut.aa;
    ct.cout=300*durloc;
     FILE* fichectrt=NULL;
     fichectrt=fopen("ContratsLocations.txt","a");
    fprintf(fichectrt,"\n N�de contrat:%f|id de voiture:%d|id de client:%d|date de debut:%d/%d/%d|date de fin:%d/%d/%d|total:%d",ct.numContrat,ct.idVoiture,ct.idClient,ct.debut.jj,ct.debut.mm,ct.debut.aa,ct.fin.jj,ct.fin.mm,ct.fin.aa,ct.cout);
    fclose(fichectrt);
}
}
}
void Retourner_voiture()
{ 
   int i=0,id_vr;
   voiture ch[1000];
   contrat ct[1000];
   FILE* fichierv=NULL;
   FILE* fichierc=NULL;
   FILE* fichiercs=NULL;
   FILE* fichier=NULL;
   printf("saisir l'id de voiture retourner :\n");
   scanf("%d",&id_vr);
   fichierv=fopen("Voitures.txt","r");
   fichier=fopen("filevr.txt","w");
   if(fichierv!=NULL)
   {   while(i<1000 && !feof(fichierv))
        {  
		    fscanf(fichierv,"\n id de voiture:%d|marque de voiture:%s|nom de voiture:%s|couleur de voiture:%s|nombre de places:%d|prix par jour:%d|location:%s",&ch[i].idVoiture,ch[i].marque,ch[i].nomVoiture,ch[i].couleur,&ch[i].nbplaces,&ch[i].prixJour,ch[i].EnLocation);
             if(ch[i].idVoiture==id_vr)
                   {
                         strcpy(ch[i].EnLocation,"non");
                   }
               fprintf(fichier,"\nid de voiture:%d|marque de voiture:%s|nom de voiture:%s|couleur de voiture:%s|nombre de places:%d|prix par jour:%d|location:%s",ch[i].idVoiture,ch[i].marque,ch[i].nomVoiture,ch[i].couleur,ch[i].nbplaces,ch[i].prixJour,ch[i].EnLocation);
            i++;
        }
    fclose(fichierv);
    fclose(fichier);
    remove("Voitures.txt");
    rename("filevr.txt","Voitures.txt");
   }
   else
   {
    printf("erreur! fichier introuvable\n ");
   }
 fichierc=fopen("ContratsLocations.txt","r");
 fichiercs=fopen("filectrt1.txt","w");
 if(fichierc!=NULL)
 {  while(i<1000 && !feof(fichierc))
      {
          fscanf(fichierc,"\n N�de contrat:%f|id de voiture:%d|id de client:%d|date de debut:%d/%d/%d|fin de fin:%d/%d/%d|total:%d",&ct[i].numContrat,&ct[i].idVoiture,&ct[i].idClient,&ct[i].debut.jj,&ct[i].debut.mm,&ct[i].debut.aa,&ct[i].fin.jj,&ct[i].fin.mm,&ct[i].fin.aa,&ct[i].cout);
          if(ct[i].idVoiture!=id_vr)
          {
              fprintf(fichiercs,"\n N�de contrat:%f|id de voiture:%d|id de client:%d|date de debut:%d/%d/%d|date de fin:%d/%d/%d| total:%d",ct[i].numContrat,ct[i].idVoiture,ct[i].idClient,ct[i].debut.jj,ct[i].debut.mm,ct[i].debut.aa,ct[i].fin.jj,ct[i].fin.mm,ct[i].fin.aa,ct[i].cout);
          }
          i++;
      }
      fclose(fichierc);
      fclose(fichiercs);
      remove("ContratsLocations.txt");
      rename("filectrt1.txt","ContratsLocations.txt");
 }
 else
    {
      printf("erreur ! fichier introuvable");
   }
}
void Modifier_contratLocation()
{ 
    int i=0,n;
    float id_ct;
    contrat ct[1000];
   FILE* Location=NULL;
   FILE* modif=NULL;
   Location=fopen("ContratsLocations.txt","r");
   modif=fopen("filemodif.txt","w");
   if(Location==NULL)
   {
       printf("erreur! fichier introuvable :\n");
   }
   else
   { 
    printf("saisir l'id du contrat que vous voulez modifier :\n");
    scanf("%f",&id_ct);
      while(i<1000 && !feof(Location))
      { 
	   fscanf(Location,"\n N�de contrat:%f|id de voiture:%d|id de client:%d|date de debut:%d/%d/%d|date de fin:%d/%d/%d|total:%d ",&ct[i].numContrat,&ct[i].idVoiture,&ct[i].idClient,&ct[i].debut.jj,&ct[i].debut.mm,&ct[i].debut.aa,&ct[i].fin.jj,&ct[i].fin.mm,&ct[i].fin.aa,&ct[i].cout);
            if(ct[i].numContrat==id_ct)
            { 
			 printf("saisir ce que vous voulez modifier:\n");
			 printf("1-id de Voiture\n");
			 printf("2-id de Client\n");
			 printf("3-date de debut\n");
			 printf("4-date de fin\n");
			 printf("5-le cout \n ");
             scanf("%d",&n);
             do{
              switch(n)
                 {  
				 case 1: 
				 printf("saisir L'id du voiture que vous voullez mettre :\n");
                            scanf("%d",&ct[i].idVoiture);
                            break;
                     case 2: 
					 printf("entrer l'id du client que vous voullez mettre :\n");
                             scanf("%d",&ct[i].idClient);
                             break;
                      case 3: 
					  printf("saisir le jour de debut de location :\n");
                              scanf("%d",&ct[i].debut.jj);
                               printf("saisir le moi de debut de location :\n");
                              scanf("%d",&ct[i].debut.mm);
                               printf("saisir l'ann�e de debut de location :\n");
                              scanf("%d",&ct[i].debut.aa);
                              break;
                       case 4:  
					   printf("saisir le jour de la fin de location :\n");
                                scanf("%d",&ct[i].fin.jj);
                               printf("saisir le moi de la fin de location :\n");
                               scanf("%d",&ct[i].fin.mm);
                               printf("saisir l'ann�e de la fin de location :\n");
                               scanf("%d",&ct[i].fin.aa);
                              break;
                        case 5:
						 printf("saisir le cout :\n");
                                scanf("%d",&ct[i].cout);
                                break;
                         default : 
						 printf("entrer une valeur entre 1 et 5 :\n");
                                   break;
                       }
            }while(n<0||n>5);
        fprintf(modif,"\n N�de contrat:%f|id de voiture:%d|id de client:%d|date de debut:%d/%d/%d|date de fin:%d/%d/%d|cout:%d",ct[i].numContrat,ct[i].idVoiture,ct[i].idClient,ct[i].debut.jj,ct[i].debut.mm,ct[i].debut.aa,ct[i].fin.jj,ct[i].fin.mm,ct[i].fin.aa,ct[i].cout);
            i++;
      }
      fclose(Location);
      fclose(modif);
      remove("ContratsLocations.txt");
      rename("filemodif.txt","ContratsLocations.txt");
   }
}
}
int MenuPrincipal()
{
	EnTete();
    int choix;
	printf("\n                               \xda\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xbf");
	printf("\n                               \xb3 Menu Principal  \xb3");
	printf("\n                               \xc0\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xd9");
    printf("\n               \xc9\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbb");
    printf("\n               \xba                                              \xba");
    printf("\n               \xba    Location..............................1   \xba");
    printf("\n               \xba    Gestion voitures......................2   \xba");
    printf("\n               \xba    Gestion clients.......................3   \xba");
    printf("\n               \xba    Quitter...............................4   \xba");
    printf("\n               \xba                                              \xba");
    printf("\n               \xc8\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbc");
    printf("\n\n                                Votre choix  :  ");
    scanf("%d",&choix);
    return choix;
}
 int Location_v()
 {
  int choix;
	printf("\n                               \xda\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xbf");
	printf("\n                               \xb3 Location voiture \xb3");
	printf("\n                               \xc0\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xd9");
    printf("\n               \xc9\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbb");
    printf("\n               \xba                                              \xba");
    printf("\n               \xba    Visualiser contrat.......................1\xba");
    printf("\n               \xba    Louer voiture............................2\xba");
    printf("\n               \xba    Retourner voiture........................3\xba");
    printf("\n               \xba    Modifier contrat.........................4\xba");
    printf("\n               \xba    Retour...................................5\xba");
    printf("\n               \xba                                              \xba");
    printf("\n               \xc8\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbc");
    printf("\n\n                                Votre choix  :  ");
    scanf("%d",&choix);
    return choix;
}
int Gestion_v()
{   
  int choix;
	printf("\n                               \xda\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xbf");
	printf("\n                               \xb3 Gestion des voitures \xb3");
	printf("\n                               \xc0\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xd9");
    printf("\n               \xc9\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbb");
    printf("\n               \xba                                              \xba");
    printf("\n               \xba    Liste des voiture........................1\xba");
    printf("\n               \xba    Ajouter voiture..........................2\xba");
    printf("\n               \xba    Modifier voiture.........................3\xba");
    printf("\n               \xba    Supprimer voiture........................4\xba");
    printf("\n               \xba    Retour...................................4\xba");
    printf("\n               \xba                                              \xba");
    printf("\n               \xc8\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbc");
    printf("\n\n                                Votre choix  :  ");
    scanf("%d",&choix);
    return choix;
}
int Gestion_c()
{
    int choix;
	printf("\n                               \xda\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xbf");
	printf("\n                               \xb3 Gestion des clients  \xb3");
	printf("\n                               \xc0\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xd9");
    printf("\n               \xc9\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbb");
    printf("\n               \xba                                                \xba");
    printf("\n               \xba    Liste des clients........................1  \xba");
    printf("\n               \xba    Ajouter client...........................2  \xba");
    printf("\n               \xba    Modifier client..........................3  \xba");
    printf("\n               \xba    Supprimer client.........................4  \xba");
    printf("\n               \xba    Retour...................................5  \xba");
    printf("\n               \xba                                                \xba");
    printf("\n               \xc8\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbc");
    printf("\n\n                                Votre choix  :  ");
    scanf("%d",&choix);
    return choix;
}
int main()
{ 
 int n1,n2,n3,n4;
  n1=MenuPrincipal();
  switch(n1)
{
   case 1: 
   n2=Location_v();
                 switch(n2)
                       { case 1: 
					             Visualiser_contrat();
                                 break;
                         case 2: 
						 		Louer_voiture();
                                 break;
                         case 3:
						 		 Retourner_voiture();
                                 break;
                          case 4:
						  		Modifier_contratLocation();
                                 break;
                          case 5:
						  		MenuPrincipal();
                                  break;
                            default :
							printf("valeur invalide! saisir un entier entre 1 et 6 \n");
							
                        }
            break;
    case 2:  
	n3= Gestion_v();
                  switch(n3)
                       { case 1:
					              affichage_voiture();
                                   break;
                          case 2:
						          Ajoute_voiture();
                                   break;
                          case 3:
						           Modifier_voiture();
                                   break;
                          case 4: 
						           Supprimer_voiture();
                                   break;
                          case 5: 
						           MenuPrincipal();
                                   break;
                           default :
						           printf("valeur invalide! saisir un entier entre 1 et 5 \n");
                       }
            break;
    case 3: 
	n4=Gestion_c();
                   switch(n4)
                       {  case 1: 
					                Afficher_client();
                                    break;
                           case 2: 
						             Ajoute_client();
                                     break;
                           case 3:  
						            Modifier_client();
                                    break;
                            case 4: 
							       supprimer_client();
                                   break;
                            case 5:
							        MenuPrincipal();
                                    break;
                             default :
							        printf("valeur invalide! saisir un entier entre 1 et 5");
                        }
            break;
    case 4: 
	       printf("                        Quitter\n ");
             break;
       default : 
	         printf("valeur errone� entrer une valeur entre 1 et 4");
  }
   return 0;
}
